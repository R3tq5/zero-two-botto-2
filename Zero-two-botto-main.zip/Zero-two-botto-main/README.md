# Zero-two-botto
A fully efficient modular whatsapp bot
